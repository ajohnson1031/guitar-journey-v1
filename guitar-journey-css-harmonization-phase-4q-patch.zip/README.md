# Guitar Journey CSS Harmonization Phase 4Q Patch

This local-only patch absorbs the approved visual overrides from `button-style-interjection.css` into the main theme/component styles.

## Files included

- `src/App.css`
- `src/styles/theme.css`
- `src/styles/buttons.css`
- `src/styles/settings.css`
- `src/styles/custom-song-form.css`
- `src/styles/complete-session.css`
- `src/styles/current-song.css`
- `src/styles/today-plan.css`
- `src/styles/dashboard-nav.css`
- `src/styles/session-history.css`
- `src/styles/weekly-plan.css`
- `src/styles/chords.css`
- `src/styles/detail-sections.css`
- `src/styles/sidebar-genre-paths.css`

## Important manual cleanup

After copying this patch, delete the old override file:

```bash
rm src/styles/button-style-interjection.css
```

`src/App.css` no longer imports it.

## What changed

- Moved the new success/edit/outline tokens into `theme.css`.
- Moved reusable green/blue outline button styles into `buttons.css`.
- Moved selected-preset white/black styling into `buttons.css`.
- Moved Stop button neutral/preset styling into `buttons.css`.
- Moved Settings microphone Stop styling into `settings.css`.
- Preserved `min-width: 87px` for `.microphone-test-button`.
- Moved Clear Paste and Analyze Paste styling into `custom-song-form.css`.
- Moved Save Custom Song / Save Completed Session green styling into `complete-session.css`.
- Moved Current Song delete, edit, mastered label, and mastered button styling into `current-song.css`.
- Moved Today’s Plan yellow 1–99% progress state into `today-plan.css`.
- Moved active session indicator styling into `dashboard-nav.css`.
- Moved Practice History playback/download/stop/delete styling into `session-history.css`.
- Moved Weekly Plan dark-mode day badge styling into `weekly-plan.css`.
- Kept the remaining semantic-token migrations for History, Weekly Plan, Chords, Detail Sections, and Genre Paths in their owning files.

## Preserved visual decisions

- Trash/delete icons use `--color-danger`.
- Weekly Plan day badge in dark mode uses:
  `border-color: var(--color-edit); background: rgba(125, 211, 252, 0.12); color: var(--color-edit);`
- Active session indicator uses edit-token border/text and transparent background.
- Active preset button uses white background and black text.
- Save buttons use the deeper green fill.
- Settings microphone Stop is filled destructive.
- Settings active badge background is transparent.

## Smoke test checklist

### 1. Apply and cleanup

```bash
rm src/styles/button-style-interjection.css
```

### 2. Run guarded checks

```bash
npm run lint
npm run test:run
npm run build
```

### 3. Visual smoke

Run the app:

```bash
npm run dev
```

Check both light and dark modes:

- Settings: microphone Test/Stop, Import/Export, active badge.
- Add Song: Clear Paste icon, Analyze Paste hover, Save Custom Song, selected presets.
- Dashboard: Save Completed Session, active session indicator, Current Song delete/edit/mastered toggle, Today’s Plan percentage indicator.
- Practice History: recording playback/download/stop/delete buttons.
- Weekly Plan: Day badges, especially dark mode.
- Chords/Transitions/Song Sections: card contrast, chord playback, transition inputs.
- Genre Paths: active path and description expansion.

### 4. Diff sanity

```bash
git diff -- src/App.css src/styles
git diff --check
```

Expected:

- `button-style-interjection.css` is deleted.
- No visual override import remains in `App.css`.
- Styling decisions are absorbed into owning style files.
