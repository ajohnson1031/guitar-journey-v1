import * as React from "react";
import { DEFAULT_CUSTOM_SONG_FORM, KEY_OPTIONS } from "../constants";
import { parseCommaList, parseSections, slugify } from "../utils/songFormUtils";
import { hasStrummingPattern, normalizeStrummingPatternData, serializeStrummingPattern } from "../utils/strummingUtils";
import { SongImportAssistant, StrummingPatternBuilder, TransitionInput } from "./";

const { useEffect, useMemo, useState } = React;

const DIFFICULTY_OPTIONS = ["Beginner", "Intermediate", "Advanced", "Expert"];

const noop = () => {};

function sectionsToText(sections) {
  if (!Array.isArray(sections) || !sections.length) {
    return DEFAULT_CUSTOM_SONG_FORM.sections;
  }

  return sections.map((section) => `${section.name || "Section"}: ${section.progression || "X - X - X - X"}`).join("\n");
}

function getDefaultForm() {
  return {
    ...DEFAULT_CUSTOM_SONG_FORM,
    strummingPattern: normalizeStrummingPatternData(DEFAULT_CUSTOM_SONG_FORM.strummingPattern),
  };
}

function getMatchingGenre(value, genres = []) {
  const normalizedValue = String(value || "").trim().toLowerCase();

  if (!normalizedValue) return "";

  return genres.find((genre) => String(genre || "").trim().toLowerCase() === normalizedValue) || "";
}

function getAppliedBpm(value) {
  const bpm = Number(value);

  if (!Number.isFinite(bpm)) return "";

  return String(Math.min(220, Math.max(40, Math.round(bpm))));
}

function songToForm(song) {
  if (!song) return getDefaultForm();

  return {
    artist: song.artist || "",
    instrument: song.instrument || "",
    title: song.title || "",
    genre: song.genre || "",
    key: song.key || "",
    tuning: song.tuning || "",
    capo: song.capo || "",
    bpm: String(song.bpm || "72"),
    difficulty: song.difficulty || "",
    chords: Array.isArray(song.chords) ? song.chords.join(", ") : "",
    transitions: Array.isArray(song.transitions) ? song.transitions.join(", ") : "",
    sections: sectionsToText(song.sections),
    strummingPattern: normalizeStrummingPatternData(song.strummingPattern || song.strumming),
    goal: song.goal || DEFAULT_CUSTOM_SONG_FORM.goal,
  };
}

export default function CustomSongForm({
  defaultOpen = false,
  editingSong,
  genres,
  onAddSong,
  onCancelEdit,
  onClose = noop,
  onOpenChange = noop,
  onUpdateSong,
  showToggle = true,
}) {
  const isEditing = Boolean(editingSong);

  const [form, setForm] = useState(() => getDefaultForm());
  const [isOpen, setIsOpen] = useState(defaultOpen);
  const [message, setMessage] = useState("");
  const [messageTone, setMessageTone] = useState("error");

  const previewChords = useMemo(() => parseCommaList(form.chords), [form.chords]);
  const strummingPattern = useMemo(() => normalizeStrummingPatternData(form.strummingPattern), [form.strummingPattern]);
  const strummingPatternText = serializeStrummingPattern(strummingPattern);

  useEffect(() => {
    if (!defaultOpen) return;

    setIsOpen(true);
    onOpenChange(true);
  }, [defaultOpen, onOpenChange]);

  useEffect(() => {
    if (!editingSong) return;

    setForm(songToForm(editingSong));
    setIsOpen(true);
    onOpenChange(true);
    setMessage("");
  }, [editingSong, onOpenChange]);

  function setValidationMessage(value) {
    setMessage(value);
    setMessageTone("error");
  }

  function setInfoMessage(value) {
    setMessage(value);
    setMessageTone("info");
  }

  function updateField(fieldName, value) {
    setForm((current) => ({
      ...current,
      [fieldName]: value,
    }));
    setMessage("");
  }

  function resetForm() {
    setForm(isEditing ? songToForm(editingSong) : songToForm(null));
    setMessage("");
  }

  function closeForm() {
    setIsOpen(false);
    onOpenChange(false);
    setMessage("");
    setForm(songToForm(null));

    if (isEditing) {
      onCancelEdit();
    }

    onClose();
  }

  function applySongAnalysis(analysis) {
    setForm((current) => {
      const matchingGenre = getMatchingGenre(analysis.genre, genres);
      const appliedBpm = getAppliedBpm(analysis.bpm);

      return {
        ...current,
        title: analysis.title || current.title,
        artist: analysis.artist || current.artist,
        instrument: analysis.instrument || current.instrument,
        genre: matchingGenre || current.genre,
        bpm: appliedBpm || current.bpm,
        chords: analysis.chords.length ? analysis.chords.join(", ") : current.chords,
        transitions: analysis.transitions.length ? analysis.transitions.join(", ") : current.transitions,
        sections: analysis.sections.length ? sectionsToText(analysis.sections) : current.sections,
        difficulty: analysis.difficulty || current.difficulty,
        key: analysis.key || current.key,
        tuning: analysis.tuning || current.tuning,
        capo: analysis.capo || current.capo,
        goal: !current.goal || current.goal === DEFAULT_CUSTOM_SONG_FORM.goal ? analysis.goal : current.goal,
      };
    });

    setInfoMessage("Song analysis applied. Review and edit anything before saving.");
  }

  function handleSubmit(event) {
    event.preventDefault();

    const title = form.title.trim();

    if (!title) {
      setValidationMessage("Add a song title before saving.");
      return;
    }

    if (!form.genre) {
      setValidationMessage("Select a genre before saving.");
      return;
    }

    if (!form.key) {
      setValidationMessage("Select a key before saving.");
      return;
    }

    if (!form.difficulty) {
      setValidationMessage("Select a difficulty before saving.");
      return;
    }

    if (!hasStrummingPattern(strummingPattern)) {
      setValidationMessage("Add at least one down or up strum to the strumming pattern.");
      return;
    }

    const chords = parseCommaList(form.chords);

    if (!chords.length) {
      setValidationMessage("Add at least one chord.");
      return;
    }

    const bpm = Number(form.bpm);

    const song = {
      id: editingSong?.id || `custom-${slugify(title)}-${Date.now()}`,
      title,
      artist: form.artist.trim(),
      instrument: form.instrument.trim(),
      genre: form.genre,
      key: form.key,
      tuning: form.tuning.trim(),
      capo: form.capo.trim(),
      bpm: Number.isFinite(bpm) ? bpm : 80,
      difficulty: form.difficulty,
      chords,
      transitions: parseCommaList(form.transitions),
      sections: parseSections(form.sections),
      strumming: strummingPatternText,
      strummingPattern,
      goal: form.goal.trim() || "Practice this song with clean timing and smooth transitions.",
      isCustom: true,
      createdAt: editingSong?.createdAt || new Date().toISOString(),
      updatedAt: new Date().toISOString(),
    };

    if (isEditing) {
      onUpdateSong(song);
    } else {
      onAddSong(song);
    }

    setMessage("");
    setMessageTone("error");
    setForm(songToForm(null));
    setIsOpen(false);
    onOpenChange(false);
  }

  return (
    <section className="panel-card custom-song-card">
      <div className="custom-song-header">
        <div>
          <h2>{isEditing ? "Edit Custom Song" : "Add Custom Song"}</h2>
          <p className="section-copy">
            {isEditing
              ? "Update this song’s study details, rhythm, sections, and practice goal."
              : "Create a personal study song with chords, sections, rhythm, and a practice goal."}
          </p>
        </div>
      </div>

      {isOpen ? (
        <form className="custom-song-form" onSubmit={handleSubmit}>
          <SongImportAssistant onApplyAnalysis={applySongAnalysis} />

          <div className="form-grid three">
            <label>
              <span>Song Title</span>
              <input type="text" value={form.title} placeholder="Example: I Want You Around" onChange={(event) => updateField("title", event.target.value)} />
            </label>

            <label>
              <span>Artist</span>
              <input type="text" value={form.artist} placeholder="Example: Snoh Aalegra" onChange={(event) => updateField("artist", event.target.value)} />
            </label>

            <label>
              <span>Instrument / Type</span>
              <input type="text" value={form.instrument} placeholder="Example: Bass, Chords, Tab" onChange={(event) => updateField("instrument", event.target.value)} />
            </label>

            <label>
              <span>Genre</span>
              <select value={form.genre} onChange={(event) => updateField("genre", event.target.value)}>
                <option value="">Select a genre...</option>
                {genres.map((genre) => (
                  <option key={genre} value={genre}>
                    {genre}
                  </option>
                ))}
              </select>
            </label>

            <label>
              <span>Difficulty</span>
              <select value={form.difficulty} onChange={(event) => updateField("difficulty", event.target.value)}>
                <option value="">Select difficulty...</option>
                {DIFFICULTY_OPTIONS.map((difficulty) => (
                  <option key={difficulty} value={difficulty}>
                    {difficulty}
                  </option>
                ))}
              </select>
            </label>

            <label>
              <span>Key</span>
              <select value={form.key} onChange={(event) => updateField("key", event.target.value)}>
                <option value="">Select a key...</option>
                {KEY_OPTIONS.map((keyOption) => (
                  <option key={keyOption} value={keyOption}>
                    {keyOption}
                  </option>
                ))}
              </select>
            </label>

            <label>
              <span>Tuning</span>
              <input type="text" value={form.tuning} placeholder="e.g., Standard, Eb Standard, Drop D" onChange={(event) => updateField("tuning", event.target.value)} />
            </label>

            <label>
              <span>BPM</span>
              <input type="number" min="40" max="220" value={form.bpm} onChange={(event) => updateField("bpm", event.target.value)} />
            </label>

            <label>
              <span>Capo</span>
              <input type="text" value={form.capo} placeholder="e.g., None, 1st fret, 3rd fret" onChange={(event) => updateField("capo", event.target.value)} />
            </label>
          </div>

          <StrummingPatternBuilder
            value={strummingPattern}
            onChange={(nextPattern) => {
              setForm((current) => ({
                ...current,
                strummingPattern: nextPattern,
              }));
              setMessage("");
            }}
          />

          <div className="form-grid two custom-song-chord-transition-row">
            <label>
              <span>Chords</span>
              <input type="text" value={form.chords} placeholder="G, C, Em, D" onChange={(event) => updateField("chords", event.target.value)} />
            </label>

            <TransitionInput value={form.transitions} onChange={(nextTransitions) => updateField("transitions", nextTransitions)} />
          </div>

          <label>
            <span>Song Sections</span>
            <textarea
              value={form.sections}
              rows="4"
              placeholder={"Verse: X - X - X - X\nChorus: X - X - X - X"}
              onChange={(event) => updateField("sections", event.target.value)}
            />
          </label>

          <label>
            <span>Practice Goal</span>
            <textarea value={form.goal} rows="3" onChange={(event) => updateField("goal", event.target.value)} />
          </label>

          <div className="custom-song-preview">
            <span>Preview chords</span>
            <div>{previewChords.length ? previewChords.map((chord) => <strong key={chord}>{chord}</strong>) : <small>No chords yet</small>}</div>
          </div>

          <div className="custom-song-actions">
            <p className={`custom-song-message ${messageTone === "error" ? "is-error" : "is-info"}`} aria-live="polite">
              {message}
            </p>

            <div className="custom-song-button-group">
              {isEditing ? (
                <button type="button" className="ghost-button" onClick={closeForm}>
                  Cancel Edit
                </button>
              ) : (
                <button type="button" className="preset-button" onClick={resetForm}>
                  Reset Form
                </button>
              )}

              <button type="submit" className="complete-session-button">
                {isEditing ? "Save Updated Song" : "Save Custom Song"}
              </button>
            </div>
          </div>
        </form>
      ) : null}
    </section>
  );
}
